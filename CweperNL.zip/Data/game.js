import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.158.0/build/three.module.js';
import { io } from 'https://cdn.jsdelivr.net/npm/socket.io-client@4.7.2/dist/socket.io.esm.min.js';

let scene, camera, renderer, raycaster;
let socket, myId, currentServer;
let treeScore = 0, stoneScore = 0;

const keys = {};
const players = {};
const playerMeshes = {};
const resources = [];
const builtBlocks = [];

let lastTime = 0;


// Mouse tracking for third-person camera rotation
let cameraAngle = 0;
let isMouseDown = false;
let previousMouseX = 0;

document.addEventListener("mousedown", e => {
  isMouseDown = true;
  previousMouseX = e.clientX;
});

document.addEventListener("mouseup", () => {
  isMouseDown = false;
});

document.addEventListener("mousemove", e => {
  if (isMouseDown) {
    const deltaX = e.clientX - previousMouseX;
    cameraAngle -= deltaX * 0.005; // adjust sensitivity
    previousMouseX = e.clientX;
  }
});

// Defining or somehting

const loader = new THREE.TextureLoader();
const grassTexture = loader.load('grass.jpg');
grassTexture.wrapS = THREE.RepeatWrapping;
grassTexture.wrapT = THREE.RepeatWrapping;
grassTexture.repeat.set(1, 1);

const tileSize = 256;  // size of one floor tile
const tiles = new Map();  // stores floor tile meshes keyed by coordinates
const renderRadius = 3;  // how many tiles away to load

// Health

let maxHealth = 100;
let currentHealth = maxHealth;

const healthBar = document.getElementById("health-bar");

function updateHealthBar() {
  const healthPercent = (currentHealth / maxHealth) * 100;
  healthBar.style.width = healthPercent + "%";

  // Change color from green to red as health drops:
  const red = Math.min(255, 255 * (1 - currentHealth / maxHealth));
  const green = Math.min(255, 255 * (currentHealth / maxHealth));
  healthBar.style.backgroundColor = `rgb(${red}, ${green}, 0)`;
}

// Tools

let currentTool = "pick"; // "pick" = mining, "hand" = building
const hotbarSlots = document.querySelectorAll("#hotbar .hotbar-slot");

const serverSelect = document.getElementById("serverSelect");
const customInput = document.getElementById("customServer");
const chatInput = document.getElementById("chat-input");
const chatMessages = document.getElementById("chat-messages");
const scoreDisplay = document.getElementById("score");
const connectBtn = document.getElementById("connectBtn");
const mineSound = document.getElementById("mine-sound");

// Trees

let isMining = false;
let miningTarget = null;
let miningProgress = 0;
const miningDuration = 1000; // milliseconds


// Keyboard input
document.addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
document.addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

// Handle key presses to switch tools (1=pick, 2=hand)
document.addEventListener("keydown", e => {
  if (e.key === "2") {
    setTool("pick");
  } else if (e.key === "1") {
    setTool("hand");
  }
});

function setTool(tool) {
  if (tool !== "pick" && tool !== "hand") return;
  currentTool = tool;
  console.log("Selected tool:", tool);

  // Update UI highlight on hotbar slots
  hotbarSlots.forEach(slot => slot.classList.remove("selected"));

  if (tool === "hand") {
    hotbarSlots[0].classList.add("selected");
    hotbarSlots[1].classList.remove("selected");
  } else if (tool === "pick") {
    hotbarSlots[1].classList.add("selected");
    hotbarSlots[0].classList.remove("selected");
  }

}

// Camera

function smoothLookAt(mesh, targetAngle, speed = 0.1) {
  const currentY = mesh.rotation.y;
  let delta = targetAngle - currentY;

  // Keep rotation in range -PI to PI
  if (delta > Math.PI) delta -= 2 * Math.PI;
  if (delta < -Math.PI) delta += 2 * Math.PI;

  mesh.rotation.y += delta * speed;
}



// Server dropdown toggle
serverSelect.addEventListener("change", () => {
  customInput.style.display = serverSelect.value === "custom" ? "inline-block" : "none";
  connectBtn.disabled = serverSelect.value === currentServer;
});

// Bind connect button to connect function
connectBtn.addEventListener("click", connectToServer);

// Chat input
chatInput.addEventListener("keydown", e => {
  if (e.key === "Enter" && chatInput.value.trim() && socket) {
    socket.emit("chat_message", {
      username: localStorage.getItem("Username") || "Anonymous",
      text: chatInput.value.trim()
    });
    chatInput.value = "";
  }
});

// Before major functions so it's global

function createFloorTile(x, z) {
  const geometry = new THREE.PlaneGeometry(tileSize, tileSize);
  const material = new THREE.MeshLambertMaterial({ map: grassTexture });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.set(x, 0, z);
  scene.add(mesh);
  return mesh;
}

function updateFloorTiles(playerX, playerZ) {
  const playerTileX = Math.floor(playerX / tileSize);
  const playerTileZ = Math.floor(playerZ / tileSize);

  const neededTiles = new Set();

  for (let dx = -renderRadius; dx <= renderRadius; dx++) {
    for (let dz = -renderRadius; dz <= renderRadius; dz++) {
      const tileX = (playerTileX + dx) * tileSize;
      const tileZ = (playerTileZ + dz) * tileSize;
      const key = `${tileX}_${tileZ}`;
      neededTiles.add(key);
      if (!tiles.has(key)) {
        const tile = createFloorTile(tileX, tileZ);
        tiles.set(key, tile);
      }
    }
  }

  // Remove tiles outside render radius
  for (const key of tiles.keys()) {
    if (!neededTiles.has(key)) {
      scene.remove(tiles.get(key));
      tiles.delete(key);
    }
  }
}


function connectToServer() {
  let url = serverSelect.value;
  if (url === "custom") {
    url = customInput.value.trim();
    if (!url) return alert("Enter server URL");
  }

  if (url === currentServer) return alert("Already connected!");

  // Cleanup
  if (socket) {
    socket.disconnect();
    Object.keys(players).forEach(id => delete players[id]);
    Object.values(playerMeshes).forEach(mesh => scene.remove(mesh));
    Object.keys(playerMeshes).forEach(id => delete playerMeshes[id]);
    resources.forEach(r => scene.remove(r.mesh));
    resources.length = 0;
  }

  currentServer = url;
  connectBtn.disabled = true;
  socket = io(url, { timeout: 5000 });

  socket.on("connect_error", () => {
    alert("Connection failed, reloading...");
    location.reload();
  });

  socket.on("disconnect", () => {
    alert("Disconnected from server.");
    currentServer = null;
    connectBtn.disabled = false;
  });

  socket.on("init", data => {
    myId = data.id;
    initScene();

    Object.entries(data.players).forEach(([id, pos]) => addPlayer(id, pos.x, pos.y));
    data.trees.forEach(t => addResource(t.x, t.y, "tree"));
    data.stones.forEach(s => addResource(s.x, s.y, "stone"));

    updateScore();
  });

  socket.on("player_joined", d => addPlayer(d.id, d.x, d.y));
  socket.on("player_left", d => removePlayer(d.id));
  socket.on("update_position", d => movePlayer(d.id, d.x, d.y));

  socket.on("chat_message", d => {
    const el = document.createElement("div");
    el.textContent = `${d.id === myId ? "You" : d.username}: ${d.text}`;
    chatMessages.appendChild(el);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  });

  socket.on("resource_mined", d => {
    const index = resources.findIndex(r => r.type === d.type && r.x === d.x && r.y === d.y);
    if (index !== -1) {
      scene.remove(resources[index].mesh);
      resources.splice(index, 1);
    }
    if (d.playerId === myId) {
      d.type === "tree" ? treeScore++ : stoneScore++;
      updateScore();
      mineSound.currentTime = 0;
      mineSound.play().catch(() => { });
    }
  });

  socket.on("building_built", data => {
    addBuildingBlock(data.x, data.y, data.z);
  });

}

function createProceduralGrassTexture() {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  // Fill base green color
  ctx.fillStyle = '#3a7e3a';
  ctx.fillRect(0, 0, size, size);

  // Add some random lighter green "grass blades"
  for (let i = 0; i < 500; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const length = 10 + Math.random() * 10;
    const angle = Math.random() * Math.PI * 2;
    ctx.strokeStyle = `rgba(50, 150, 50, ${0.1 + Math.random() * 0.3})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(angle) * length, y + Math.sin(angle) * length);
    ctx.stroke();
  }

  return new THREE.CanvasTexture(canvas);
}

function getPlayerBoundingBox() {
  const playerMesh = playerMeshes[myId];
  if (!playerMesh) return null;
  playerMesh.geometry.computeBoundingBox();
  const box = playerMesh.geometry.boundingBox.clone();
  box.min.add(playerMesh.position);
  box.max.add(playerMesh.position);
  return box;
}

function initScene() {
  scene = new THREE.Scene();

  // Floor texture
  const floorTexture = createProceduralGrassTexture();
  floorTexture.wrapS = THREE.RepeatWrapping;
  floorTexture.wrapT = THREE.RepeatWrapping;
  floorTexture.repeat.set(20, 20);

  // Skybox background
  const loader = new THREE.TextureLoader();
  loader.load('Skybox.jpg', function (texture) {
    scene.background = texture;
  });

  // Health UI
  updateHealthBar();

  // Camera
  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.set(0, 50, 200);

  // Renderer
  renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  // Raycaster
  raycaster = new THREE.Raycaster();

  // 🌤️ Ambient light (soft overall lighting)
  const ambientLight = new THREE.AmbientLight(0x888888); // softer than white
  scene.add(ambientLight);

  // ☀️ Directional light (for shadows & gloss)
  const dirLight = new THREE.DirectionalLight(0xffffff, 1);
  dirLight.position.set(100, 200, 100);
  dirLight.castShadow = false; // You can turn this on later if needed
  scene.add(dirLight);

  // Resize listener
  window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  // Click handler
  window.addEventListener("click", onClickAction);

  // Start game loop
  animate();
}


function addPlayer(id, x, y) {
  players[id] = { x, y };

  const loader = new THREE.TextureLoader();

  const materials = [
    new THREE.MeshLambertMaterial({ map: loader.load('Body.png') }), // Right
    new THREE.MeshLambertMaterial({ map: loader.load('Body.png') }), // Left
    new THREE.MeshLambertMaterial({ map: loader.load('Body.png') }), // Top
    new THREE.MeshLambertMaterial({ map: loader.load('Body.png') }), // Bottom
    new THREE.MeshLambertMaterial({ map: loader.load('Body.png') }), // Front
    new THREE.MeshLambertMaterial({ map: loader.load('Face.png') }), // Back
  ];

  const geom = new THREE.BoxGeometry(10, 10, 10);
  const cube = new THREE.Mesh(geom, materials);
  cube.position.set(x, 5, y);

  // Compute bounding box for collision detection
  cube.geometry.computeBoundingBox();

  playerMeshes[id] = cube;
  scene.add(cube);
}




function addBuildingBlock(x, y, z) {
  const geom = new THREE.BoxGeometry(10, 10, 10);
  const mat = new THREE.MeshLambertMaterial({ color: 0x8b4513 }); // brown block
  const block = new THREE.Mesh(geom, mat);
  block.position.set(x, y, z);
  scene.add(block);
  builtBlocks.push(block);

  // Compute and store bounding box (for collision detection)
  block.geometry.computeBoundingBox();
  block.userData.boundingBox = block.geometry.boundingBox.clone();
  block.userData.boundingBox.min.add(block.position);
  block.userData.boundingBox.max.add(block.position);
  block.geometry.computeBoundingBox();

}



function removePlayer(id) {
  if (playerMeshes[id]) {
    scene.remove(playerMeshes[id]);
    delete playerMeshes[id];
  }
  delete players[id];
}

function movePlayer(id, x, y) {
  if (players[id]) {
    players[id].x = x;
    players[id].y = y;
    playerMeshes[id].position.set(x, 5, y);
  }
}

function addResource(x, z, type) {
  let mesh;

  if (type === "tree") {
    const group = new THREE.Group();

    const trunkHeight = 10 + Math.random() * 5;
    const trunkRadius = 2 + Math.random();

    const trunkGeo = new THREE.CylinderGeometry(trunkRadius, trunkRadius, trunkHeight, 8);
    const trunkMat = new THREE.MeshLambertMaterial({ color: 0x8B4513 });
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.y = trunkHeight / 2; // center trunk vertically
    group.add(trunk);

    const leavesHeight = 15 + Math.random() * 10;
    const leavesRadius = 7 + Math.random() * 3;
    const leavesGeo = new THREE.ConeGeometry(leavesRadius, leavesHeight, 8);
    const leavesMat = new THREE.MeshLambertMaterial({ color: 0x228B22 });
    const leaves = new THREE.Mesh(leavesGeo, leavesMat);
    leaves.position.y = trunkHeight + leavesHeight / 2;
    group.add(leaves);

    mesh = group;
    mesh.position.set(x, 0, z); // ✅ place the tree base at y = 0 (ground level)

  } else if (type === "stone") {
    const geo = new THREE.DodecahedronGeometry(6, 0); // rock-like shape
    const mat = new THREE.MeshLambertMaterial({ color: 0x777777, flatShading: true });
    mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, 3, z); // small Y value to rest on ground

    // Optionally rotate randomly to make it less uniform
    mesh.rotation.x = Math.random() * Math.PI;
    mesh.rotation.y = Math.random() * Math.PI;

    mesh.geometry.computeBoundingBox();
  }

  resources.push({ x, y: z, type, mesh }); // ⚠️ Note: storing 'y' as z for consistency with server format
  scene.add(mesh);
}




function updateScore() {
  scoreDisplay.textContent = `Trees mined: ${treeScore} | Stones mined: ${stoneScore}`;
  scoreDisplay.style.display = "block";
}

function onClickAction(event) {
  const mouse = {
    x: (event.clientX / window.innerWidth) * 2 - 1,
    y: -(event.clientY / window.innerHeight) * 2 + 1
  };
  raycaster.setFromCamera(mouse, camera);

  if (currentTool === "pick") {
    if (isMining) return; // Prevent starting another mining while already mining

    // Collect all meshes from resources, including groups like trees
    const meshesToCheck = [];
    resources.forEach(r => {
      if (r.mesh.isGroup) {
        meshesToCheck.push(...r.mesh.children);
      } else {
        meshesToCheck.push(r.mesh);
      }
    });

    const intersects = raycaster.intersectObjects(meshesToCheck);

    if (intersects.length === 0 || !players[myId]) return;

    // Find which resource corresponds to the intersected mesh
    const targetMesh = intersects[0].object;
    const resource = resources.find(r => {
      if (r.mesh.isGroup) {
        return r.mesh.children.includes(targetMesh);
      } else {
        return r.mesh === targetMesh;
      }
    });
    if (!resource) return;

    // Check if player is close enough to mine
    const dx = players[myId].x - resource.x;
    const dy = players[myId].y - resource.y;
    if (Math.hypot(dx, dy) < 50) {
      // Start mining animation & disable movement
      isMining = true;
      miningTarget = resource;
      miningProgress = 0;
      miningStartY = null; // Reset mining start Y for animation
    }

  } else if (currentTool === "hand") {
    // Building mode (unchanged)
    const groundIntersects = raycaster.intersectObjects(Array.from(tiles.values()));
    if (groundIntersects.length === 0 || !players[myId]) return;

    const point = groundIntersects[0].point;
    const buildX = Math.round(point.x / 10) * 10;
    const buildZ = Math.round(point.z / 10) * 10;
    const buildY = 5;

    const dx = players[myId].x - buildX;
    const dz = players[myId].y - buildZ;

    if (Math.hypot(dx, dz) < 50) {
      if (treeScore < 1) {
        alert("Not enough wood to build!");
        return;
      }

      treeScore--;
      updateScore();
      socket.emit("build", { x: buildX, y: buildY, z: buildZ });
    }
  }
}



// Add this global variable at the top of your script, outside animate():
let miningStartY = null;

function animate(time = performance.now()) {
  requestAnimationFrame(animate);

  if (!lastTime) lastTime = time;
  const delta = time - lastTime;
  lastTime = time;

  const speed = isMining ? 0 : 2;
  let dx = 0, dy = 0;

  // Movement input
  if (keys["w"]) {
    dx -= Math.sin(cameraAngle) * speed;
    dy -= Math.cos(cameraAngle) * speed;
  }
  if (keys["s"]) {
    dx += Math.sin(cameraAngle) * speed;
    dy += Math.cos(cameraAngle) * speed;
  }
  if (keys["a"]) {
    dx -= Math.cos(cameraAngle) * speed;
    dy += Math.sin(cameraAngle) * speed;
  }
  if (keys["d"]) {
    dx += Math.cos(cameraAngle) * speed;
    dy -= Math.sin(cameraAngle) * speed;
  }

  // Normalize movement vector
  const length = Math.hypot(dx, dy);
  if (length > 0) {
    dx /= length;
    dy /= length;
    dx *= speed;
    dy *= speed;
  }

  // Mining animation and logic
  if (isMining && miningTarget) {
    miningProgress += delta;

    if (miningStartY === null) {
      miningStartY = miningTarget.mesh.position.y; // Store initial Y once
    }

    const sinkDistance = 20; // How far to sink the resource underground
    miningTarget.mesh.position.y = miningStartY - (miningProgress / miningDuration) * sinkDistance;

    if (miningProgress >= miningDuration) {
      // Remove the resource mesh from the scene
      scene.remove(miningTarget.mesh);

      // Remove from resource list
      const idx = resources.indexOf(miningTarget);
      if (idx !== -1) resources.splice(idx, 1);

      // Update score locally
      if (miningTarget.type === "tree") treeScore++;
      else if (miningTarget.type === "stone") stoneScore++;
      updateScore();

      // Notify server of mining event
      socket.emit("mine", { type: miningTarget.type, x: miningTarget.x, y: miningTarget.y });

      // Reset mining variables
      isMining = false;
      miningTarget = null;
      miningProgress = 0;
      miningStartY = null;
    }
  }

  // Movement and collision handling (unchanged from your original code)
  if ((dx !== 0 || dy !== 0) && socket) {
    const playerMesh = playerMeshes[myId];
    if (playerMesh) {
      if (!playerMesh.geometry.boundingBox) {
        playerMesh.geometry.computeBoundingBox();
      }

      const newX = playerMesh.position.x + dx;
      const newZ = playerMesh.position.z + dy;

      // Clone and translate player's bounding box to new position
      const playerBox = playerMesh.geometry.boundingBox.clone();
      const offset = new THREE.Vector3(newX, playerMesh.position.y, newZ).sub(playerMesh.position);
      playerBox.min.add(offset);
      playerBox.max.add(offset);

      let collision = false;

      for (const block of builtBlocks) {
        if (!block.userData.boundingBox) continue;

        if (playerBox.intersectsBox(block.userData.boundingBox)) {
          collision = true;
          break;
        }
      }

      if (!collision) {
        socket.emit("move", { dx, dy });
      }
    }
  }

  // Prevent player from walking into blocks (unchanged)
  if (myId && playerMeshes[myId]) {
    const playerPos = playerMeshes[myId].position;
    const playerBox = new THREE.Box3().setFromCenterAndSize(playerPos, new THREE.Vector3(10, 10, 10));

    for (const block of builtBlocks) {
      const blockBox = new THREE.Box3().setFromObject(block);
      if (playerBox.intersectsBox(blockBox)) {
        // Undo movement if colliding
        playerPos.x -= dx;
        playerPos.z -= dy;
        break;
      }
    }
  }

  // Update floor tiles around player
  if (myId && playerMeshes[myId]) {
    const pos = playerMeshes[myId].position;
    updateFloorTiles(pos.x, pos.z);
  }

  // Camera follow and rotation smoothing (unchanged)
  if (myId && playerMeshes[myId]) {
    const target = playerMeshes[myId].position;
    const distance = 100;
    const height = 50;
    const camX = target.x + Math.sin(cameraAngle) * distance;
    const camZ = target.z + Math.cos(cameraAngle) * distance;
    const camY = target.y + height;
    camera.position.set(camX, camY, camZ);
    camera.lookAt(target);
  }

  // Player smooth rotation to match camera angle while moving
  if (myId && playerMeshes[myId]) {
    const playerMesh = playerMeshes[myId];
    const dxMove = dx;
    const dyMove = dy;
    const isMoving = dxMove !== 0 || dyMove !== 0;

    if (isMoving) {
      const targetRotation = cameraAngle;
      let deltaRotation = targetRotation - playerMesh.rotation.y;
      deltaRotation = Math.atan2(Math.sin(deltaRotation), Math.cos(deltaRotation));
      playerMesh.rotation.y += deltaRotation * 0.1;
    }
  }

  renderer.render(scene, camera);
}
