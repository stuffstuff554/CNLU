import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.158.0/build/three.module.js';
import { io } from 'https://cdn.jsdelivr.net/npm/socket.io-client@4.7.2/dist/socket.io.esm.min.js';

let scene, camera, renderer, raycaster;
let socket, myId, currentServer;
let treeScore = 0, stoneScore = 0;

const keys = {};
const players = {};
const playerMeshes = {};
const resources = [];

// Mouse tracking for third-person camera rotation
let cameraAngle = 0;
let isMouseDown = false;
let previousMouseX = 0;

document.addEventListener("mousedown", e => {
  isMouseDown = true;
  previousMouseX = e.clientX;
});

document.addEventListener("mouseup", () => {
  isMouseDown = false;
});

document.addEventListener("mousemove", e => {
  if (isMouseDown) {
    const deltaX = e.clientX - previousMouseX;
    cameraAngle -= deltaX * 0.005; // adjust sensitivity
    previousMouseX = e.clientX;
  }
});

// Defining or somehting

const loader = new THREE.TextureLoader();
const grassTexture = loader.load('grass.jpg');
grassTexture.wrapS = THREE.RepeatWrapping;
grassTexture.wrapT = THREE.RepeatWrapping;
grassTexture.repeat.set(1, 1);

const tileSize = 256;  // size of one floor tile
const tiles = new Map();  // stores floor tile meshes keyed by coordinates
const renderRadius = 3;  // how many tiles away to load


const serverSelect = document.getElementById("serverSelect");
const customInput = document.getElementById("customServer");
const chatInput = document.getElementById("chat-input");
const chatMessages = document.getElementById("chat-messages");
const scoreDisplay = document.getElementById("score");
const connectBtn = document.getElementById("connectBtn");
const mineSound = document.getElementById("mine-sound");

// Keyboard input
document.addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
document.addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

// Server dropdown toggle
serverSelect.addEventListener("change", () => {
  customInput.style.display = serverSelect.value === "custom" ? "inline-block" : "none";
  connectBtn.disabled = serverSelect.value === currentServer;
});

// Bind connect button to connect function
connectBtn.addEventListener("click", connectToServer);

// Chat input
chatInput.addEventListener("keydown", e => {
  if (e.key === "Enter" && chatInput.value.trim() && socket) {
    socket.emit("chat_message", {
      username: localStorage.getItem("Username") || "Anonymous",
      text: chatInput.value.trim()
    });
    chatInput.value = "";
  }
});

// Before major functions so it's global

function createFloorTile(x, z) {
  const geometry = new THREE.PlaneGeometry(tileSize, tileSize);
  const material = new THREE.MeshLambertMaterial({ map: grassTexture });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.set(x, 0, z);
  scene.add(mesh);
  return mesh;
}

function updateFloorTiles(playerX, playerZ) {
  const playerTileX = Math.floor(playerX / tileSize);
  const playerTileZ = Math.floor(playerZ / tileSize);

  const neededTiles = new Set();

  for (let dx = -renderRadius; dx <= renderRadius; dx++) {
    for (let dz = -renderRadius; dz <= renderRadius; dz++) {
      const tileX = (playerTileX + dx) * tileSize;
      const tileZ = (playerTileZ + dz) * tileSize;
      const key = `${tileX}_${tileZ}`;
      neededTiles.add(key);
      if (!tiles.has(key)) {
        const tile = createFloorTile(tileX, tileZ);
        tiles.set(key, tile);
      }
    }
  }

  // Remove tiles outside render radius
  for (const key of tiles.keys()) {
    if (!neededTiles.has(key)) {
      scene.remove(tiles.get(key));
      tiles.delete(key);
    }
  }
}


function connectToServer() {
  let url = serverSelect.value;
  if (url === "custom") {
    url = customInput.value.trim();
    if (!url) return alert("Enter server URL");
  }

  if (url === currentServer) return alert("Already connected!");

  // Cleanup
  if (socket) {
    socket.disconnect();
    Object.keys(players).forEach(id => delete players[id]);
    Object.values(playerMeshes).forEach(mesh => scene.remove(mesh));
    Object.keys(playerMeshes).forEach(id => delete playerMeshes[id]);
    resources.forEach(r => scene.remove(r.mesh));
    resources.length = 0;
  }

  currentServer = url;
  connectBtn.disabled = true;
  socket = io(url, { timeout: 5000 });

  socket.on("connect_error", () => {
    alert("Connection failed, reloading...");
    location.reload();
  });

  socket.on("disconnect", () => {
    alert("Disconnected from server.");
    currentServer = null;
    connectBtn.disabled = false;
  });

  socket.on("init", data => {
    myId = data.id;
    initScene();

    Object.entries(data.players).forEach(([id, pos]) => addPlayer(id, pos.x, pos.y));
    data.trees.forEach(t => addResource(t.x, t.y, "tree"));
    data.stones.forEach(s => addResource(s.x, s.y, "stone"));

    updateScore();
  });

  socket.on("player_joined", d => addPlayer(d.id, d.x, d.y));
  socket.on("player_left", d => removePlayer(d.id));
  socket.on("update_position", d => movePlayer(d.id, d.x, d.y));

  socket.on("chat_message", d => {
    const el = document.createElement("div");
    el.textContent = `${d.id === myId ? "You" : d.username}: ${d.text}`;
    chatMessages.appendChild(el);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  });

  socket.on("resource_mined", d => {
    const index = resources.findIndex(r => r.type === d.type && r.x === d.x && r.y === d.y);
    if (index !== -1) {
      scene.remove(resources[index].mesh);
      resources.splice(index, 1);
    }
    if (d.playerId === myId) {
      d.type === "tree" ? treeScore++ : stoneScore++;
      updateScore();
      mineSound.currentTime = 0;
      mineSound.play().catch(() => { });
    }
  });
}

function createProceduralGrassTexture() {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  // Fill base green color
  ctx.fillStyle = '#3a7e3a';
  ctx.fillRect(0, 0, size, size);

  // Add some random lighter green "grass blades"
  for (let i = 0; i < 500; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const length = 10 + Math.random() * 10;
    const angle = Math.random() * Math.PI * 2;
    ctx.strokeStyle = `rgba(50, 150, 50, ${0.1 + Math.random() * 0.3})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(angle) * length, y + Math.sin(angle) * length);
    ctx.stroke();
  }

  return new THREE.CanvasTexture(canvas);
}


function initScene() {
  scene = new THREE.Scene();

  const floorTexture = createProceduralGrassTexture();
  floorTexture.wrapS = THREE.RepeatWrapping;
  floorTexture.wrapT = THREE.RepeatWrapping;
  floorTexture.repeat.set(20, 20);

  // Overlapping floor
  //const floorGeometry = new THREE.PlaneGeometry(1920, 1080);
  //const floorMaterial = new THREE.MeshLambertMaterial({ map: floorTexture });
  //const floor = new THREE.Mesh(floorGeometry, floorMaterial);
  //floor.rotation.x = -Math.PI / 2;
  //floor.position.y = 0;
  //scene.add(floor);

  const loader = new THREE.TextureLoader();
  loader.load('Skybox.jpg', function (texture) {
    scene.background = texture; // This sets the sky image as the scene’s background
  });





  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  renderer = new THREE.WebGLRenderer();
  document.body.appendChild(renderer.domElement);
  renderer.setSize(window.innerWidth, window.innerHeight);
  raycaster = new THREE.Raycaster();

  const light = new THREE.AmbientLight(0xffffff);
  scene.add(light);

  camera.position.set(0, 50, 200);

  window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  window.addEventListener("click", onClickMine);

  animate();
}

function addPlayer(id, x, y) {
  players[id] = { x, y };
  const geom = new THREE.BoxGeometry(10, 10, 10);
  const mat = new THREE.MeshBasicMaterial({ color: id === myId ? 0x0000ff : 0xff0000 });
  const cube = new THREE.Mesh(geom, mat);
  cube.position.set(x, 5, y);
  playerMeshes[id] = cube;
  scene.add(cube);
}

function removePlayer(id) {
  if (playerMeshes[id]) {
    scene.remove(playerMeshes[id]);
    delete playerMeshes[id];
  }
  delete players[id];
}

function movePlayer(id, x, y) {
  if (players[id]) {
    players[id].x = x;
    players[id].y = y;
    playerMeshes[id].position.set(x, 5, y);
  }
}

function addResource(x, y, type) {
  let mesh, yPos;

  if (type === "tree") {
    const geo = new THREE.ConeGeometry(10, 30, 8);
    const mat = new THREE.MeshLambertMaterial({ color: 0x228b22 });
    mesh = new THREE.Mesh(geo, mat);
    yPos = 15; // half height of cone
  } else {
    const geo = new THREE.SphereGeometry(8, 16, 16);
    const mat = new THREE.MeshLambertMaterial({ color: 0x888888 });
    mesh = new THREE.Mesh(geo, mat);
    yPos = 8; // radius of sphere
  }

  mesh.position.set(x, yPos, y);
  resources.push({ x, y, type, mesh });
  scene.add(mesh);
}


function updateScore() {
  scoreDisplay.textContent = `Trees mined: ${treeScore} | Stones mined: ${stoneScore}`;
  scoreDisplay.style.display = "block";
}

function onClickMine(event) {
  const mouse = {
    x: (event.clientX / window.innerWidth) * 2 - 1,
    y: -(event.clientY / window.innerHeight) * 2 + 1
  };
  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObjects(resources.map(r => r.mesh));
  if (intersects.length === 0 || !players[myId]) return;

  const target = intersects[0].object;
  const resource = resources.find(r => r.mesh === target);
  const dx = players[myId].x - resource.x;
  const dy = players[myId].y - resource.y;

  if (Math.hypot(dx, dy) < 50) {
    socket.emit("mine", { type: resource.type, x: resource.x, y: resource.y });
  }
}

function animate() {
  requestAnimationFrame(animate);

  const speed = 2;
  let dx = 0, dy = 0;

  if (keys["w"]) {
    dx -= Math.sin(cameraAngle) * speed;
    dy -= Math.cos(cameraAngle) * speed;
  }
  if (keys["s"]) {
    dx += Math.sin(cameraAngle) * speed;
    dy += Math.cos(cameraAngle) * speed;
  }
  if (keys["a"]) {
    dx -= Math.cos(cameraAngle) * speed;
    dy += Math.sin(cameraAngle) * speed;
  }
  if (keys["d"]) {
    dx += Math.cos(cameraAngle) * speed;
    dy -= Math.sin(cameraAngle) * speed;
  }

  const length = Math.hypot(dx, dy);
  if (length > 0) {
    dx /= length;
    dy /= length;
    dx *= speed;
    dy *= speed;
  }

  if ((dx !== 0 || dy !== 0) && socket) {
    socket.emit("move", { dx, dy });
  }

  if (myId && playerMeshes[myId]) {
    const pos = playerMeshes[myId].position;
    updateFloorTiles(pos.x, pos.z);
  }




  // Update camera to follow player with rotation
  if (myId && playerMeshes[myId]) {
    const target = playerMeshes[myId].position;

    const distance = 100;
    const height = 50;

    const camX = target.x + Math.sin(cameraAngle) * distance;
    const camZ = target.z + Math.cos(cameraAngle) * distance;
    const camY = target.y + height;

    camera.position.set(camX, camY, camZ);
    camera.lookAt(target);
  }

  renderer.render(scene, camera);
}
