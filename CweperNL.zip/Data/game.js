// game.js
window.addEventListener("DOMContentLoaded", () => {
  const WORLD_W = 1920, WORLD_H = 1080;
  let socket = null, myId = null, currentServer = null, gameLoopStarted = false;
  const players = {}, trees = [], stones = [];
  let treeScore = 0, stoneScore = 0;

  // DOM refs
  const canvas       = document.getElementById("Canvas");
  const ctx          = canvas.getContext("2d");
  const serverSelect = document.getElementById("serverSelect");
  const customInput  = document.getElementById("customServer");
  const connectBtn   = document.querySelector("button[onclick='connectToServer()']");
  const chatInput    = document.getElementById("chat-input");
  const chatMessages = document.getElementById("chat-messages");
  const scoreDisplay = document.getElementById("score");
  const mineSound    = document.getElementById("mine-sound");
  const keys         = {};

  // disable until you choose a new server
  connectBtn.disabled = true;

  // track WS keypresses
  document.addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
  document.addEventListener("keyup",   e => keys[e.key.toLowerCase()] = false);

  // show/hide custom‐URL input
  serverSelect.addEventListener("change", () => {
    customInput.style.display = serverSelect.value === "custom" ? "inline-block" : "none";
    connectBtn.disabled = serverSelect.value === currentServer;
  });

  // resize canvas
  function resizeToFit() {
    const vw = window.innerWidth, vh = window.innerHeight;
    const scale = Math.min(vw/WORLD_W, vh/WORLD_H);
    const cw = Math.floor(WORLD_W * scale), ch = Math.floor(WORLD_H * scale);
    const mvert = Math.floor((vh - ch)/2);
    canvas.style.width  = `${cw}px`;
    canvas.style.height = `${ch}px`;
    canvas.style.marginTop    = `${mvert}px`;
    canvas.style.marginBottom = `${mvert}px`;
  }
  window.addEventListener("resize", resizeToFit);

  // update & reveal score
  function updateScoreDisplay() {
    scoreDisplay.textContent = `Trees mined: ${treeScore} | Stones mined: ${stoneScore}`;
    scoreDisplay.style.display = "block";
  }

  function getUsername() {
    const n = localStorage.getItem("Username");
    return n && n.trim() ? n.trim() : "Anonymous";
  }

  // connect / reconnect
  function connectToServer() {
    let url = serverSelect.value;
    if (url === "custom") {
      url = customInput.value.trim();
      if (!url) { alert("Enter server URL"); return; }
    }
    if (url === currentServer) {
      alert("Already connected!"); return;
    }

    // teardown old session
    if (socket) {
      socket.disconnect();
      socket = null;
      myId = null;
      Object.keys(players).forEach(id => delete players[id]);
      trees.length = stones.length = 0;
      chatMessages.innerHTML = "";
      treeScore = stoneScore = 0;
      scoreDisplay.style.display = "none";
    }

    currentServer = url;
    connectBtn.disabled = true;
    socket = io(url, { timeout: 5000 });

    socket.on("connect_error", () => {
      alert("Connection failed, reloading...");
      location.reload();
    });
    socket.on("disconnect", () => {
      alert("Disconnected from server.");
      currentServer = null;
      connectBtn.disabled = false;
    });

    socket.on("init", data => {
      console.log("[Socket] init:", data);
      myId = data.id;
      console.log("→ myId set to", myId);

      Object.assign(players, data.players);
      canvas.width  = WORLD_W;
      canvas.height = WORLD_H;
      resizeToFit();

      if (Array.isArray(data.trees))  trees.splice(0, trees.length, ...data.trees);
      if (Array.isArray(data.stones)) stones.splice(0, stones.length, ...data.stones);

      treeScore = stoneScore = 0;
      updateScoreDisplay();  // guarantee it shows on init
    });

    socket.on("player_joined", d   => players[d.id] = { x:d.x, y:d.y });
    socket.on("update_position", d => {
      if (players[d.id]) players[d.id] = { x:d.x, y:d.y };
    });
    socket.on("player_left", d     => delete players[d.id]);

    // chat
    chatInput.addEventListener("keydown", e => {
      if (e.key === "Enter" && chatInput.value.trim() && socket.connected) {
        socket.emit("chat_message", {
          text:     chatInput.value.trim(),
          username: getUsername()
        });
        chatInput.value = "";
      }
    });
    socket.on("chat_message", d => {
      const el = document.createElement("div");
      el.textContent = `${d.id===myId?"You":d.username}: ${d.text}`;
      chatMessages.appendChild(el);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    });

    // resource mined
    socket.on("resource_mined", d => {
      if (!myId) {
        console.warn("Got resource_mined before myId was assigned");
        return;
      }
      const arr = d.type === "tree" ? trees : stones;
      const idx = arr.findIndex(r => r.x===d.x && r.y===d.y);
      if (idx !== -1) arr.splice(idx,1);

      if (d.playerId === myId) {
        d.type === "tree" ? treeScore++ : stoneScore++;
        updateScoreDisplay();
        mineSound.currentTime = 0;
        mineSound.play().catch(()=>{});
      }
    });

    // start the render loop exactly once
    if (!gameLoopStarted) {
      gameLoopStarted = true;
      requestAnimationFrame(loop);
    }
  }

  // movement emitter
  function sendMovement() {
    let dx = 0, dy = 0;
    if (keys["w"]) dy -= 2;
    if (keys["s"]) dy += 2;
    if (keys["a"]) dx -= 2;
    if (keys["d"]) dx += 2;
    if ((dx||dy) && socket) socket.emit("move", { dx, dy });
  }

  // click to mine
  canvas.addEventListener("click", e => {
    if (!socket || !myId || !players[myId]) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width/rect.width, scaleY = canvas.height/rect.height;
    const cx = (e.clientX-rect.left)*scaleX, cy = (e.clientY-rect.top)*scaleY;
    const p = players[myId];
    if (Math.hypot(p.x-cx, p.y-cy) > 50) return;

    for (const [arr, type] of [[trees,"tree"],[stones,"stone"]]) {
      for (const r of arr) {
        if (Math.hypot(r.x-cx, r.y-cy) < 30) {
          socket.emit("mine", { type, x:r.x, y:r.y });
          return;
        }
      }
    }
  });

  // drawing
  function drawBackground() {
    ctx.fillStyle = "#2c7a2c";
    ctx.fillRect(0,0,WORLD_W,WORLD_H);
  }
  function drawTrees() {
    for (const t of trees) {
      ctx.fillStyle = "#654321";
      ctx.fillRect(t.x-5, t.y, 10, 30);
      ctx.beginPath();
      ctx.fillStyle = "#228B22";
      ctx.arc(t.x, t.y, 20, 0, Math.PI*2);
      ctx.fill();
    }
  }
  function drawStones() {
    for (const s of stones) {
      ctx.fillStyle = "#888";
      ctx.beginPath();
      ctx.arc(s.x, s.y, 15, 0, Math.PI*2);
      ctx.fill();
    }
  }
  function drawPlayers() {
    for (const id in players) {
      const p = players[id];
      ctx.fillStyle = id===myId ? "blue" : "red";
      ctx.fillRect(p.x, p.y, 20, 20);
    }
  }
  function loop() {
    drawBackground();
    drawTrees();
    drawStones();
    drawPlayers();
    sendMovement();
    requestAnimationFrame(loop);
  }

  window.connectToServer = connectToServer;
});
